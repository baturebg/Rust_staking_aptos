
pub struct HumanReadableAccount {
    pub account_id: AccountId,
    /// The balance that can be withdrawn.
    pub withdraw_balance: U128,
    /// The amount that is presently staked.
    pub deposit_balance: U128,
    /// Whether the deposit balance is available for withdrawal now.
    pub can_withdraw: bool,
}

/// AptosVault interface
trait AptosVault {

    fn deposit(&mut self);

    fn withdraw(&mut self, amount: U128);

}


pub struct Vault {
    deposits: LookupMap<AccountId, u128>,
    /// for testing purpose, simulates contract panic
    panic: bool,
}


impl Vault {
    #[init]
    pub fn new() -> Self {
        Self {
            deposits: LookupMap::new(b"d"),
            panic: false,
        }
    }
}

impl AptosVault for Vault {

    #[payable]
    fn deposit(&mut self) {
        require!(!self.panic, "Test Panic!");
        self.internal_deposit()
    }

    
    fn withdraw(&mut self, amount: U128) {
        require!(!self.panic, "Test Panic!");
        let account_id = env::predecessor_account_id();
        self.internal_withdraw(&account_id, amount.0);
    }

    
}

impl Vault {

    pub fn set_panic(&mut self, panic: bool) {
        self.panic = panic;
    }

}

impl Vault {
    fn internal_deposit(&mut self) {
        let account_id = env::predecessor_account_id();
        let amount = env::attached_deposit();
        assert!(amount > 0);

        let new_deposit = amount;

        self.deposits.insert(&account_id, &new_deposit);
    }

    fn internal_withdraw(&mut self, account_id: &AccountId, amount: u128) {
        let deposited_amount = self.internal_get_deposit_balance(account_id);
        assert!(deposited_amount >= amount);

        let new_deposited = deposited_amount - amount;
        self.deposits.insert(account_id, &new_deposited);

        Promise::new(account_id.clone()).transfer(amount);
    }

    fn internal_get_deposit_balance(&self, account_id: &AccountId) -> u128 {
        self.deposits.get(account_id).unwrap_or_default()
    }


}
